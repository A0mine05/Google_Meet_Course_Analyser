<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Document sans titre</title>
</head>
	
<body>
<?php
	
	$servername = 'localhost';
	$username = 'root';
	$password='!@mD.A';
	$database= 'Google_meet';

	$email = $_POST['email'];
	$mdp = $_POST['mdp'];
	$conn = mysqli_connect($servername,$username,$password,$database); 
	
	$query = "SELECT * FROM USER WHERE email ='$email' and mdp='$mdp' ";
	$result = mysqli_query($conn,$query);
	$row = mysqli_num_rows($result);
	//echo $row;

	if(!empty($_REQUEST['email']) && !empty($_REQUEST['mdp']) )
		{
			if($row)
			{
				header( 'Location: Selection_classe_Mat.php' ) ;
				if ($conn -> connect_error)
				{
					die('Erreur : ' .$conn->connect_error);
				}
			}
			else
			{
				header( 'Location: Erreur.html' ) ;
			}
		}

		else
		{
			header( 'Location: Erreur.html' ) ;
		}

?>
	
</body>
</html>
<?php
session_start();
$reponse0 = isset($_POST['rep']) ? $_POST['rep'] : NULL;
$reponse1 = isset($_POST['rep1']) ? $_POST['rep1'] : NULL;
$reponse2 = isset($_POST['rep2']) ? $_POST['rep2'] : NULL;
$reponse3 = isset($_POST['rep3']) ? $_POST['rep3'] : NULL;
$reponse4 = isset($_POST['rep4']) ? $_POST['rep4'] : NULL;
$reponse5 = isset($_POST['rep5']) ? $_POST['rep5'] : NULL;
$reponse6 = isset($_POST['rep6']) ? $_POST['rep6'] : NULL;
$reponse7 = isset($_POST['rep7']) ? $_POST['rep7'] : NULL;
$reponse8 = isset($_POST['rep8']) ? $_POST['rep8'] : NULL;
$reponse9 = isset($_POST['rep9']) ? $_POST['rep9'] : NULL;
$reponse10 = isset($_POST['rep10']) ? $_POST['rep10'] : NULL;
$reponse11 = isset($_POST['rep11']) ? $_POST['rep11'] : NULL;
$reponse12 = isset($_POST['rep12']) ? $_POST['rep12'] : NULL;
$reponse13 = isset($_POST['rep13']) ? $_POST['rep13'] : NULL;
$reponse14 = isset($_POST['rep14']) ? $_POST['rep14'] : NULL;
$reponse15 = isset($_POST['rep15']) ? $_POST['rep15'] : NULL;
$reponse16 = isset($_POST['rep16']) ? $_POST['rep16'] : NULL;
$reponse17 = isset($_POST['rep17']) ? $_POST['rep17'] : NULL;
$reponse18 = isset($_POST['rep18']) ? $_POST['rep18'] : NULL;
$reponse19 = isset($_POST['rep19']) ? $_POST['rep19'] : NULL;



try
{
	$bdd = new PDO('mysql:host=localhost;dbname=googlemeet;charset=utf8', 'root', 'passer');


	$sth=$bdd->prepare("
	 			INSERT INTO reponse(reponse0, reponse1, reponse2, reponse3, reponse4, reponse5, reponse6, reponse7, reponse8, reponse9, reponse10, reponse11, reponse12, reponse13, reponse14, reponse15, reponse16, reponse17, reponse18, reponse19) VALUES (:reponse0, :reponse1, :reponse2, :reponse3, :reponse4, :reponse5, :reponse6, :reponse7, :reponse8, :reponse9, :reponse10, :reponse11, :reponse12, :reponse13, :reponse14, :reponse15, :reponse16, :reponse17, :reponse18, :reponse19 ) ");


	$sth->execute(array(
					 'reponse0' => $reponse0,
					 'reponse1' => $reponse1,
					 'reponse2' => $reponse2,
					 'reponse3' => $reponse3,
					 'reponse4' => $reponse4,
					 'reponse5' => $reponse5,
					 'reponse6' => $reponse6,
					 'reponse7' => $reponse7,
					 'reponse8' => $reponse8,
					 'reponse9' => $reponse9,
					 'reponse10' => $reponse10,
					 'reponse11' => $reponse11,
					 'reponse12' => $reponse12,
					 'reponse13' => $reponse13,
					 'reponse14' => $reponse14,
					 'reponse15' => $reponse15,
					 'reponse16' => $reponse16,
					 'reponse17' => $reponse17,
					 'reponse18' => $reponse18,
					 'reponse19' => $reponse19
					 	 ));

}
catch(Exception $e)
{
	die('Erreur : ' . $e->getMessage());
}


?>

<script type="text/javascript">
                alert("Reponse enregistrée avec succès");
                window.location = './FORM%20(7).html';
      </script>